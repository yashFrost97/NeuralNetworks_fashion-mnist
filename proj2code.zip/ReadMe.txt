Main.ipynb file is inside the scripts folder
